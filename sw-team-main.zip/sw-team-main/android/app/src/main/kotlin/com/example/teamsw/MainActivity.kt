package com.example.teamsw

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
